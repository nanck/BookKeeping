package com.android.book;

import android.app.Application;

/**
 * Created by sxshi on 2019-4-17.
 */

public class BookkeepApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
